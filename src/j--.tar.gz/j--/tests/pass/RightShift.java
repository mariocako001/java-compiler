package pass;

public class RightShift{
	public int rightShift(int x, int y){
		return x >> y;
	}
}
