package pass;

public class Not {
	public int not(int x) {
		return ~x;
	}
}
