package pass;

public class LeftShift {
	public int leftShift(int x, int y) {
		return x << y;
	}
}
