package pass;

public class And{
	public int and(int x, int y){
		return x & y;
	}
}
