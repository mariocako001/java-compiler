package pass;

public class LogicalRightShift{
	public int logicalRightShift(int x, int y){
		return x >>> y;
	}
}
