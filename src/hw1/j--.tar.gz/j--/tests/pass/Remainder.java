package pass;

public class Remainder{
	public int remainder(int x, int y){
		return x % y;
	}
}
