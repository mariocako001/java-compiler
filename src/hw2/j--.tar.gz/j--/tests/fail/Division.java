package fail;

import java.lang.System;

public class Division{
	public static void main(String[] args{
		System.out.println('a'/ 42);
	}
}
