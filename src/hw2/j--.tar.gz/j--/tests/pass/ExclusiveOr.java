package pass;

public class ExclusiveOr{
	public int exclusiveOr(int x, int y){
		return x ^ y;
	}
}
