package pass;

public class InclusiveOr{
	public int inclusiveOr(int x, int y){
		return x | y;
	}
}
